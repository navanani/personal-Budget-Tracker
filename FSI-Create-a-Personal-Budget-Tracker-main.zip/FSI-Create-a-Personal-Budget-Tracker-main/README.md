# Personal Budget Planner

This is an activity for FSWD Lesson 1.10.4- Arrays & Iteration.

Please refer to the Activity Guide in Canvas for directions.
